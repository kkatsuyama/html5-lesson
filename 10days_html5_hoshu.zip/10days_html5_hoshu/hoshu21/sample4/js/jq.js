$(function(){
	$("#container span").css("color", "red");
});
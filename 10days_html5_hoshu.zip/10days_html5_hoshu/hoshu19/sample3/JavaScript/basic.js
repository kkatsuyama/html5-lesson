for(I=1; I<=10; I=I+1)
{
	document.getElementById("screen1").innerHTML += I+"<br>"
}
 
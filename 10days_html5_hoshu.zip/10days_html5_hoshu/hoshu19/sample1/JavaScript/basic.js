// ここは注釈です
document.getElementById("screen1").innerHTML = "Sample";

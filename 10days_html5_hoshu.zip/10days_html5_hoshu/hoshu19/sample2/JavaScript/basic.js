A = 10
B = 5
C = A + B
document.getElementById("screen1").innerHTML = "A + B = "+C;

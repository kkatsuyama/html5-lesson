A = new Array()
for(I=1; I<=10; I=I+1)
{
	A[I] = I + 10
	document.getElementById("screen1").innerHTML += A[I]+"<br>"
}
// 語尾を変換する関数
function convert(text){
	text = text.replace(/です/g,"だ");
	return text;
}
